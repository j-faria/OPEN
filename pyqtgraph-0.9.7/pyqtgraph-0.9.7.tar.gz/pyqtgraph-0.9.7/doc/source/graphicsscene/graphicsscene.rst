GraphicsScene
=============

.. autoclass:: pyqtgraph.GraphicsScene
    :members:

    .. automethod:: pyqtgraph.GraphicsScene.__init__

