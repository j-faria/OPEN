GLGraphicsItem
==============

.. autoclass:: pyqtgraph.opengl.GLGraphicsItem
    :members:

    .. automethod:: pyqtgraph.GLGraphicsItem.__init__

