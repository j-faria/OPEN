GraphItem
=========

.. autoclass:: pyqtgraph.GraphItem
    :members:

    .. automethod:: pyqtgraph.GraphItem.__init__

