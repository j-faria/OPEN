GradientWidget
==============

.. autoclass:: pyqtgraph.GradientWidget
    :members:

    .. automethod:: pyqtgraph.GradientWidget.__init__

