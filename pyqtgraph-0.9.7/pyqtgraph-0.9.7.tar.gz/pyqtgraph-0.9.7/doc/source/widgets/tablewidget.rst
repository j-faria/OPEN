TableWidget
===========

.. autoclass:: pyqtgraph.TableWidget
    :members:

    .. automethod:: pyqtgraph.TableWidget.__init__

