VerticalLabel
=============

.. autoclass:: pyqtgraph.VerticalLabel
    :members:

    .. automethod:: pyqtgraph.VerticalLabel.__init__

