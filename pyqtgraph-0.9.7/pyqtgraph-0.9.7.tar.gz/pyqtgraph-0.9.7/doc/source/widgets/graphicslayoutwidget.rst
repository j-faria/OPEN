GraphicsLayoutWidget
====================

.. autoclass:: pyqtgraph.GraphicsLayoutWidget
    :members:

    .. automethod:: pyqtgraph.GraphicsLayoutWidget.__init__

