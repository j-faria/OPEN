FeedbackButton
==============

.. autoclass:: pyqtgraph.FeedbackButton
    :members:

    .. automethod:: pyqtgraph.FeedbackButton.__init__

