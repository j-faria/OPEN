ImageView
=========

.. autoclass:: pyqtgraph.ImageView
    :members:

    .. automethod:: pyqtgraph.ImageView.__init__

