ParameterItem
=============

.. autoclass:: pyqtgraph.parametertree.ParameterItem
    :members:

    .. automethod:: pyqtgraph.parametertree.ParameterItem.__init__

